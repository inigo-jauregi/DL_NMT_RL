#! /bin/sh

java -jar AlignViz.jar
